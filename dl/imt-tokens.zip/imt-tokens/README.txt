IMT Design — 토큰 꾸러미
=========================

파일
  tokens.css      값의 단일 출처. 색·크기·간격·라운드·그림자·모션.
  components.css  버튼·카드·배지·입력·아이콘 등 기본 부품.
  patterns.css    표·대시보드 같은 짜임새.
  guide.css       문서용 도해 스타일. 앱에는 필요 없다.
  starter.html    위 셋만으로 만든 최소 화면.

쓰는 법
  <link rel="stylesheet" href="tokens.css">
  <link rel="stylesheet" href="components.css">

규칙
  1. 값을 직접 쓰지 않는다. #6e6e74 가 아니라 var(--sub) 이라고 쓴다.
  2. 사이트가 덮어써도 되는 토큰은 --brand / --brand-hover / --brand-soft 셋뿐이다.
  3. 다크 모드는 :root[data-theme=dark] 에서 저절로 바뀐다. 따로 쓸 것이 없다.

문서  https://design.imaketoo.com
아이콘 https://icons.imaketoo.com
